# vmsg2csv
convert vmsg format(sms backup file) to csv format

# usage
$ python vmsg2csv.py input.vmsg out.csv
